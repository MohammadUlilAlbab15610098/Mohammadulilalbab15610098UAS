<?php

$name = $email = $address = $date_birth = $gender = $age = $comment = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name     = $_POST["nama"];
  $email     = $_POST["Email"];
  $address    = $_POST["alamat"];
  $date_birth  = $_POST['tgl_lhr'];
  $gender      = $_POST['jns_klmin'];
  $age  = $_POST['usia'];
  $comment  = $_POST['alasan'];
}
?>
<!DOCTYPE html>
<html id="abc" name="name1">
	<head id="abc" name="name2">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
<head>
    <title>tugas</title>
        <style type="text/css">
            .jumbotron {
                background-image: url(../coba/jumbotron.jpg);
                background-position: 0-370px;
                background-size: cover;
                    font-size: 20px;
                    padding: 60px;
                    /* background-color: #677c80; */
   
                    text-align: center;
                    color: black;
            }
            .background{
                background-image: url(../coba/gambar.png);
                background-repeat: no-repeat;
                background-size: cover;
                width: 45%;
                margin:auto;
                padding: 20px;
            }
			body{
				width: 500px;
				margin: auto;
                margin-top: 50px;
                
            }

			input{
				min-width: 100px;
				width: 200px;
			}
			textarea{
				min-width: 200px;
				max-width: 400px;
				min-height: 100px;
				width: 300px;
				height: 100px;
			}
			.bold{
				font-weight: bold;
                font-size: 2.5em;
                
            }
            table{
                color: white;
            }
            footer {
                padding: 20px;
                color: white;
                background-color: #00a2c6;
                text-align: center;
                font-weight: bold;
            }
            .profile header {
                text-align: center;
                
            }

            .profile p {
                text-align: center;
            }

            .profile a{
                text-decoration: none;
                color: #07c600;
                padding: 5px;
                margin-bottom: 5px;
                
            }
            .profile a:hover {
                font-weight: bold;
            }
            .profile img {
                width: 300px;
                height: auto;
            }
		</style>
    </head>
    <script type="text/javascript" id="abc">
        let i = 1;
			function kirim() {
				var a=document.getElementById("abc").innerHTML;
				var b=document.getElementById("txt-nama").value;
                var c=document.getElementById("txt-email").value;
                var d=document.getElementById("txt-alamat").value;
                var e=document.getElementById("txt-jenis kelamin").value;
                var f=document.getElementById("txt-usia").value;
				var g=document.getElementById("kepala").value;
				document.write(a + "<br />" + "<br />");
                document.write(b + "<br />" + "<br />");
                document.write(c + "<br />" + "<br />");
                document.write(d + "<br />" + "<br />");
                document.write(e + "<br />" + "<br />");
				document.write(f + "<br />");
                document.write(g);
                document.getElementById('txt-nama').value='';
                document.getElementById('txt-email').value='';
                document.getElementById('txt-alamat').value='';
                document.getElementById('txt-jenis kelamin').value='';
                document.getElementById('txt-usia').value='';
                document.getElementById('kepala').value='';
                document.getElementById("count").innerHTML=i;
                i++;
                
            }
		</script>
</head>
<body>
    <body background="gambar.png">
    
    <header>
        <div class="jumbotron">
        <h1>FORMULIR DATA MAKESTA</h1>
    </header>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
 <table>
  <tr><td>Nama Lengkap </td><td><input type="text" name="nama"></td></tr>
  <tr><td>Email </td><td><input type="text" name="Email"></td></tr>
  <tr><td>Alamat </td><td><textarea name="alamat" width="300"></textarea></td></tr>
  <tr><td>Tanggal Lahir</td><td><input type='date' name='tgl_lhr'/></td></tr>  
  <tr><td>Jenis Kelamin</td>
   <td>
    <input type="radio" name="jns_klmin" value="Pria" checked> Pria
    <input type="radio" name="jns_klmin" value="Wanita"> Wanita
   </td>
  </tr>
  <tr><td>Usia</td><td><input type="number" name="usia"></td></tr>
   </td>
   <tr><td>Alasan</td><td><input type='text' name='alasan'/></td></tr>
  </tr>
  <tr><td><input type="submit" value="Simpan" name="simpan"></td></tr>
  
 </table>
<br/><br/>
<?php
echo '<table>';
echo '<tr><td>'.'Nama Lengkap      : '.'</td><td>'.$name.'</td></tr>';
echo '<tr><td>'.'Email             : '.'</td><td>'.$email.'</td></tr>';
echo '<tr><td>'.'Alamat            : '.'</td><td>'.$address.'</td></tr>';
echo '<tr><td>'.'Tanggal Lahir     : '.'</td><td>'.$date_birth.'</td></tr>';
echo '<tr><td>'.'Jenis Kelamin     : '.'</td><td>'.$gender.'</td></tr>';
echo '<tr><td>'.'Usia              : '.'</td><td>'.$age.'</td></tr>';
echo '<tr><td>'.'Alasan            : '.'</td><td>'.$comment.'</td></tr>';
echo '</table>';

?>
    
    <footer>
        <p>Contact Person 087887433732 Amadhea Aisyatul Aisyiyah</p>
    </footer>
</body>
</html>