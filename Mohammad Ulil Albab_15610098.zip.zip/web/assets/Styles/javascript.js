alert("Selamat Datang, Jangan Lupa SLoooott dulu, Kakek Merah Menunggumu looo")

var slideIndex = 1;
merbabu(slideIndex);
semeru(slideIndex);
rinjani(slideIndex);
kerinci(slideIndex);
gede(slideIndex);
function plusSlides(n) {
  merbabu(slideIndex += n);
  semeru(slideIndex += n);
  rinjani(slideIndex += n);
  kerinci(slideIndex += n);
  gede(slideIndex += n);
}

function currentSlide(n) {
  merbabu(slideIndex = n);
  semeru(slideIndex += n);
  rinjani(slideIndex += n);
  kerinci(slideIndex += n);
  gede(slideIndex += n);
}

function merbabu(n) {
  var i;
  var slides = document.getElementsByClassName("merbabu");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
function semeru(n) {
  var i;
  var slides = document.getElementsByClassName("semeru");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
function rinjani(n) {
  var i;
  var slides = document.getElementsByClassName("rinjani");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
function kerinci(n) {
  var i;
  var slides = document.getElementsByClassName("kerinci");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
function gede(n) {
  var i;
  var slides = document.getElementsByClassName("gede");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
